#!/bin/bash
#
# Convert PRD.md to prd.json using Ollama
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECTS_DIR="$SCRIPT_DIR/projects"
TEMPLATES_DIR="$SCRIPT_DIR/templates"

# Default model for conversion (use a capable model)
CONVERT_MODEL="${CONVERT_MODEL:-llama3.1:latest}"

if [ $# -eq 0 ]; then
    echo "Usage: $0 <project-name> [model]"
    echo ""
    echo "Example: $0 my-feature"
    echo "         $0 my-feature deepseek-coder:33b"
    echo ""
    echo "Default model: $CONVERT_MODEL"
    echo "Override with: CONVERT_MODEL=model-name $0 <project>"
    exit 1
fi

PROJECT_NAME="$1"
MODEL="${2:-$CONVERT_MODEL}"
PROJECT_DIR="$PROJECTS_DIR/$PROJECT_NAME"

if [ ! -d "$PROJECT_DIR" ]; then
    echo "Error: Project '$PROJECT_NAME' not found"
    echo "Run: ./new.sh $PROJECT_NAME"
    exit 1
fi

PRD_MD="$PROJECT_DIR/prd.md"
PRD_JSON="$PROJECT_DIR/prd.json"
SCHEMA="$TEMPLATES_DIR/prd-schema.json"

if [ ! -f "$PRD_MD" ]; then
    echo "Error: $PRD_MD not found"
    exit 1
fi

if [ ! -f "$SCHEMA" ]; then
    echo "Error: Schema template not found: $SCHEMA"
    exit 1
fi

echo "Converting PRD to JSON format..."
echo "Project: $PROJECT_NAME"
echo "Model: $MODEL"
echo ""

# Check if model exists
if ! ollama list | grep -q "^${MODEL%%:*}"; then
    echo "Model $MODEL not found locally. Pulling..."
    ollama pull "$MODEL"
fi

# Create conversion prompt
TEMP_PROMPT=$(mktemp)
cat > "$TEMP_PROMPT" << 'EOF'
You are a technical project analyst. Convert the following Product Requirements Document (PRD) into a structured JSON format.

The JSON should follow this schema:
```json
{
  "branchName": "ralph/feature-name",
  "userStories": [
    {
      "id": "1.1",
      "category": "technical|functional|ui",
      "story": "One-sentence description",
      "steps": [
        "Step 1: Specific action",
        "Step 2: Next action",
        "Step 3: Verification step"
      ],
      "acceptance": "Detailed acceptance criteria",
      "priority": 1,
      "passes": false,
      "notes": ""
    }
  ]
}
```

IMPORTANT RULES:
1. Break down the PRD into discrete, implementable user stories
2. Each story should be completable in one session
3. Priority: 1-10 = MVP (do first), 11-20 = Phase 2, 21+ = Phase 3
4. Lower priority number = higher importance
5. All stories start with passes: false
6. Category must be one of: technical, functional, ui
7. Steps should be actionable and specific
8. Include a branchName following the pattern: ralph/<feature-name>

PRD TO CONVERT:
================================================================================
EOF

cat "$PRD_MD" >> "$TEMP_PROMPT"

cat >> "$TEMP_PROMPT" << 'EOF'
================================================================================

Output ONLY valid JSON following the schema above. No explanations, no markdown formatting, just pure JSON.
EOF

echo "Analyzing PRD with $MODEL..."
RESPONSE=$(ollama run "$MODEL" "$(cat "$TEMP_PROMPT")")

# Extract JSON from response (in case model adds explanation)
JSON=$(echo "$RESPONSE" | sed -n '/^{/,/^}/p' | head -n1)

if [ -z "$JSON" ]; then
    # Try to find JSON between code blocks
    JSON=$(echo "$RESPONSE" | sed -n '/```json/,/```/p' | sed '1d;$d')
fi

if [ -z "$JSON" ]; then
    echo "Error: Could not extract JSON from model response"
    echo "Response was:"
    echo "$RESPONSE"
    rm "$TEMP_PROMPT"
    exit 1
fi

# Validate JSON
if ! echo "$JSON" | jq . > /dev/null 2>&1; then
    echo "Error: Generated JSON is invalid"
    echo "Response:"
    echo "$JSON"
    rm "$TEMP_PROMPT"
    exit 1
fi

# Save JSON
echo "$JSON" | jq . > "$PRD_JSON"

rm "$TEMP_PROMPT"

# Show summary
STORY_COUNT=$(jq '[.userStories[]] | length' "$PRD_JSON")
BRANCH_NAME=$(jq -r '.branchName' "$PRD_JSON")

echo ""
echo "✓ PRD converted successfully"
echo ""
echo "Branch: $BRANCH_NAME"
echo "Stories: $STORY_COUNT"
echo ""
echo "Preview:"
jq -r '.userStories[] | "  [\(.id)] \(.story) (priority: \(.priority))"' "$PRD_JSON" | head -n 10

if [ $STORY_COUNT -gt 10 ]; then
    echo "  ... and $((STORY_COUNT - 10)) more"
fi

echo ""
echo "Next: ./start.sh $PROJECT_NAME --monitor"
echo ""
