# Product Requirements Document

## Overview
Brief description of what you want to build.

## Goals
What are you trying to achieve?

## Features

### Core Features
1. **Feature 1**: Description
2. **Feature 2**: Description

### Phase 2 Features
1. **Feature 3**: Description

## Technical Requirements
- Technology stack
- Dependencies
- Architecture notes

## Acceptance Criteria
How will you know when this is done?

## Notes
Any additional context or constraints.
